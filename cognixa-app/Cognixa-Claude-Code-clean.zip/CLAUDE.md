# Cognixa → Claude Code (clean pack)

UI source only. No desktop-agent / BC Set / RFC zips.

## Run
```bash
# Windows: double-click START-COGNIXA.cmd
# Or:
python -m http.server 8765
# open http://127.0.0.1:8765/Cognixa.html
```
Do **not** open `Cognixa.html` from inside a zip / Temp folder (shows raw `{{ }}`).

## Files
| File | Role |
|------|------|
| `Cognixa.html` | Main app (edit this) |
| `Cognixa.dc_25th July.html` | Twin — keep **byte-identical** when you change UI |
| `support.js` | DC runtime (required) |
| `vendor/react*.js` | React (required) |
| `FeedbackToast.dc.html` | Imported toast host |
| `START-COGNIXA.cmd` | Windows local server launcher |

## Repo
- `rajesh-sha/Test` · branch `cursor/cognixa-july-features-7d34` · PR #3

## Product rules (do not regress)
- Browser Cognixa = demo + evidence only — **cannot** write SAP `T001` / create company codes
- On-Prem config prefer **BC Sets + CTS**; Public Cloud = **CBC** only
- Prefer surgical diffs; do not rewrite whole `Cognixa.html`
- When editing UI/JS, update **both** HTML twins identically

## A4H (non-secret)
SID A4H · host 115.245.150.98 · inst 18 · client 800 · user Rajesh1 · connection `S4HANA2023 SHARED GUI`  
Never commit passwords.
