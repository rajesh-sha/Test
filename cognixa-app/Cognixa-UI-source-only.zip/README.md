# Cognixa UI source

## Run on Windows
1. Extract All this zip (do not open HTML from inside the zip)
2. Double-click **START-COGNIXA.cmd**
3. Browser opens http://127.0.0.1:8765/Cognixa.html

Opening Cognixa.html from Temp/zip shows raw {{ }} — that is not a Cognixa bug.
