# Cognixa UI source (only)

This is the Cognixa app you see in the browser — nothing else.

## Files
- `Cognixa.html` — main app
- `Cognixa.dc_25th July.html` — twin (keep identical if you edit)
- `support.js` — required runtime
- `vendor/react*.js` — required
- `FeedbackToast.dc.html`, `index.html`

## Run
```bash
cd cognixa-ui-only
python3 -m http.server 8765
# open http://localhost:8765/Cognixa.html
```
Do not open Cognixa.html via file:// alone.
